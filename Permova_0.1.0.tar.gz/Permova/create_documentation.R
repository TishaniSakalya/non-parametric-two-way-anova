
# Set working directory to the path your package is
setwd("C:/Users/sakal/Documents/Permova")

# Install package if you haven't already
library(roxygen2)
roxygenize()
roxygenize("R")

devtools::install()

library(Permova)

?choose_bootstrap_type  # Check if documentation loads
choose_bootstrap_type(data)  # Run function

?power_analysis_permutation_future

usethis::use_vignette("method_intro")
devtools::build_vignettes()

install.packages("testthat")
library(testthat)

usethis::use_testthat()

usethis::use_test("bootstrap_function")
usethis::use_test("calculate_eta_squared")
usethis::use_test("choose_bootstrap_type")
usethis::use_test("eta_squared")
usethis::use_test("get_coef_name")
usethis::use_test("permute_and_fit")
usethis::use_test("permute_data")
usethis::use_test("stratified_perm_test_sequential")
usethis::use_test("summarize_permutation_results")
usethis::use_test("power_analysis")


devtools::test()


devtools::build()
